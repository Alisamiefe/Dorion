#include "HideCommand.h"

HideCommand::HideCommand() : IMCCommand("hide", "hide the mod", "") {
}

HideCommand::~HideCommand() {
}

bool HideCommand::execute(std::vector<std::string>* args) {
	GameData::hide();
	if (GameData::shouldHide()) {
		clientMessageF("[%sDorion%s] %sHidden.", DARK_PURPLE, WHITE, GREEN);
	} else {
		clientMessageF("[%sDorion%s] %sMod is now visible.", DARK_PURPLE, WHITE, GREEN);
	}
	return true;
}
