#pragma once

#include "Module.h"

class TPSM : public IModule {
private:
public:
	TPSM();
	~TPSM();

	// Inherited via IModule
	virtual void onTick(GameMode* gm) override;
	virtual const char* getModuleName() override;
};