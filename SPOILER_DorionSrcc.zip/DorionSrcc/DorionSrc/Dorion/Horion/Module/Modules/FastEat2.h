#pragma once

class FastEat2 : public IModule {
public:
	FastEat2() : IModule(0x0, Category::MISC, "Eat food almost instant") {}
	~FastEat2(){};

	// Inherited via IModule
	virtual const char* getModuleName() override { return ("InstaEat"); }
	virtual void onTick(GameMode* gm) override {
		PlayerInventoryProxy* supplies = Game.getLocalPlayer()->getSupplies();
		Inventory* inv = supplies->inventory;
		for (int i = 0; i < 36; i++) {
			ItemStack* stack = inv->getItemStack(i);
			if (stack->item != NULL && (*stack->item)->itemId != 261 && (*stack->item)->getMaxUseDuration(stack) == 32) {
				(*stack->item)->setMaxUseDuration(1);
			}
		}
	}
	virtual void onDisable() override {
		if (Game.getLocalPlayer() == nullptr)
			return;
		PlayerInventoryProxy* supplies = Game.getLocalPlayer()->getSupplies();
		Inventory* inv = supplies->inventory;
		for (int i = 0; i < 36; i++) {
			ItemStack* stack = inv->getItemStack(i);
			if (stack->item != NULL && (*stack->item)->itemId != 261 && (*stack->item)->getMaxUseDuration(stack) == 1) {
				(*stack->item)->setMaxUseDuration(32);
			}
		}
	}
};