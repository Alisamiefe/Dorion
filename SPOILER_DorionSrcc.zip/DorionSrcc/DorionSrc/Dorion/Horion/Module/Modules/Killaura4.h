#pragma once
#include "../../../Utils/Target.h"
#include "../ModuleManager.h"
#include "Module.h"

class Killaura4 : public IModule {
private:
	bool isMulti = true;
	int delay = 0;
	int Odelay = 0;
	bool autoweapon = false;
	void findWeapon();
	bool silent = true;
	bool cps = true;
	bool strafe = true;
	int idk = 0;

public:
	SettingEnum rots{this};
	bool isMobAura = false;
	bool VisTarget = false;
	bool hurttime = false;
	float range = 6;

	Killaura4();
	~Killaura4();

	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm) override;
	virtual void onEnable() override;
	virtual void onDisable() override;
	virtual void onPlayerTick(Player* player) override;
	virtual void onSendPacket(Packet* packet) override;
	virtual void onLevelRender() override;
};