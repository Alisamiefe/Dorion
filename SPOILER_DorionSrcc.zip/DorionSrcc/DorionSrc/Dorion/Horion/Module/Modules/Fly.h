#pragma once

#include "Module.h"

class Fly : public IModule {
private:
	float speed = 1.5f;
	float upanddown = 0.5;
	float glideMod = -0.001f;
	float glideModEffective = 8.f;
	bool border = true;
	bool borderD = true;
	int tmp = 1;
	int tick = 0;
	int tickTimer = 1.5;

	int gameTick = 0;

public:
	bool bypass = true;

	Fly();
	~Fly();

	// Inherited via IModule
	virtual void onEnable() override;
	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm) override;
	virtual void onDisable() override;
	virtual void onMove(MoveInputHandler* input) override;
};
