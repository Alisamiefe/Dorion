#include "TPSM.h"

TPSM::TPSM() : IModule(0, Category::WORLD, "Command: .tp X Y Z") {
}

TPSM::~TPSM() {}

const char* TPSM::getModuleName() {
	return "TeleportSMbeta";
}

void TPSM::onTick(GameMode* gm) {
}