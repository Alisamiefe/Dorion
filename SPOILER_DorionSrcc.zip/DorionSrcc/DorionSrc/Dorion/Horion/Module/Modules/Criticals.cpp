#include "Criticals.h"
#include "../../Utils/TimerUtil.h"

Criticals::Criticals() : IModule(0, Category::COMBAT, "Each hit becomes a critical hit.") {
	registerFloatSetting("value", &this->glideMod, this->glideMod, -0.018, -0.018f);
	registerBoolSetting("test", &test, test);
}

Criticals::~Criticals() {
}

const char* Criticals::getModuleName() {
	return "Criticals";
}

void Criticals::onTick(GameMode* gm) {
	gm->player->aabb.upper.y = gm->player->aabb.lower.y - (float)1.8f;
	gm->player->entityLocation->velocity = Vec3(0, 0, 0);
	glideModEffective = glideMod;
	GameSettingsInput* input = Game.getClientInstance()->getGameSettingsInput();

	if (Game.canUseMoveKeys()) {
		if (GameData::isKeyDown(*input->spaceBarKey))
			glideModEffective += 0.2f;
		if (GameData::isKeyDown(*input->sneakKey))
			glideModEffective -= 0.2f;

		float reverse = glideMod * -7.425;
		Vec3 pos2 = *Game.getLocalPlayer()->getPos();
		if (TimerUtil::hasTimedElapsed(150, true)) gm->player->setPos(pos2.add(Vec3(0.f, reverse, 0.f)));
	}
	gm->player->entityLocation->velocity.y = glideModEffective;
}
