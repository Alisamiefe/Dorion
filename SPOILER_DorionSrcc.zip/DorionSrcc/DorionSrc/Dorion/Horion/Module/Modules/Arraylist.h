#pragma once

#include "..\ModuleManager.h"
#include "Module.h"
#include "../../../Utils/ColorUtil.h"

class Arraylist : public IModule {
public:
	bool clickToggle = true;
	float alpha = 1.f;
	float cycleSpeed = 3.f;
	float saturation = 1.f;
	bool Bar = true;
	bool bottom = false;
	bool Bar2 = true;
	bool underbar = false;
	// bool Flux = false;
	int arrayColor;
	bool RGB = true;

	// I will make do this another time
	SettingEnum style = SettingEnum(this);

	Arraylist();
	~Arraylist();

	// Inherited via IModule
	virtual const char* getModuleName();
	virtual void onPostRender(MinecraftUIRenderContext* renderCtx);
};