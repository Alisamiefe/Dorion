#pragma once

#include "Module.h"

class Fly1 : public IModule {
private:
	float speed = 1.5f;
	float upanddown = 0.5;
	float glideMod = -0.01f;
	float glideModEffective = 0.f;
	Vec3 oldPos;
	bool NoPacket = false;
	bool border = true;
	int tmp = 1;

	int gameTick = 0;

public:
	bool bypass = true;

	Fly1();
	~Fly1();

	// Inherited via IModule
	virtual void onEnable() override;
	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm) override;
	virtual void onDisable() override;
	virtual void onMove(MoveInputHandler* input) override;
};