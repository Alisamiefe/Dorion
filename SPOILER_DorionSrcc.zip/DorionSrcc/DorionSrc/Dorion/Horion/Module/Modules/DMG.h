#pragma once

#include "../../../Utils/Target.h"
#include "../ModuleManager.h"
#include "Module.h"

class DMG : public IModule {
private:
	/*bool displayPosition = true;
	bool displayDistance = true;
	bool displayHealth = true;
	bool displayArmor = true;*/
	SettingEnum Color;
	bool Player = false;
	Entity* target = nullptr;

public:
	int range = 60.f;
	DMG();
	~DMG();

	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm) override;
};