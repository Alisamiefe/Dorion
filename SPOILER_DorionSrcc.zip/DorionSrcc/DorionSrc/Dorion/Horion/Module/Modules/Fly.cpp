#include "Fly.h"
#include "../../Utils/TimerUtil.h"

Fly::Fly() : IModule('F', Category::CLIENT, "Fly Lifeboat") {
	registerFloatSetting("Horizontal Speed", &this->speed, this->speed, 0.1f, 9.f);
	registerFloatSetting("Vertical Speed", &this->upanddown, this->upanddown, 0.1f, 9.f);
    registerFloatSetting("Float", &this->glideMod, this->glideMod, -0.0108, -0.0108f);
	registerBoolSetting("border", &this->border, this->border);
	//registerBoolSetting("bypass", &this->bypass, this->bypass);
	registerBoolSetting("BlockSound", &this->borderD, this->borderD);
}

Fly::~Fly() {
}

const char *Fly::getModuleName() {
	return "FastFly";
}

void Fly::onTick(GameMode *gm) {
	gm->player->aabb.upper.y = gm->player->aabb.lower.y - (float)1.8f;
	gm->player->entityLocation->velocity = Vec3(0, 0, 0);
	glideModEffective = glideMod;
	GameSettingsInput *input = Game.getClientInstance()->getGameSettingsInput();

	if (Game.canUseMoveKeys()) {
		if (GameData::isKeyDown(*input->spaceBarKey))
			glideModEffective += 0.2f;
		if (GameData::isKeyDown(*input->sneakKey))
			glideModEffective -= 0.2f;
	}
	if (bypass) {
		float reverse = glideMod * -2.425;
		Vec3 pos2 = *Game.getLocalPlayer()->getPos();
		if (TimerUtil::hasTimedElapsed(74.4, true)) gm->player->setPos(pos2.add(Vec3(0.f, reverse, 0.f)));
	}
	if (borderD) {
		tick++;
		if (tick >= tickTimer) {
			gm->player->setOnGround(true);
			gm->player->jumpFromGround();
			tick = 0;
		}
	}
	gm->player->entityLocation->velocity.y = glideModEffective;
}

void Fly::onMove(MoveInputHandler *input) {
	auto player = Game.getLocalPlayer();
	if (player == nullptr) return;
	LocalPlayer *localPlayer = Game.getLocalPlayer();
	if (localPlayer == nullptr)
		return;

	bool keyPressed = false;
	GameSettingsInput *inputf = Game.getClientInstance()->getGameSettingsInput();
	bool jumping = GameData::isKeyDown(*inputf->spaceBarKey);
	bool sneaking = GameData::isKeyDown(*inputf->sneakKey);

	float calcYaw = (localPlayer->getActorRotationComponent()->rot.y + 90) * (PI / 180);
	float c = cos(calcYaw);
	float s = sin(calcYaw);

	Vec2 moveVec2D = {input->forwardMovement, -input->sideMovement};
	bool flag = moveVec2D.magnitude() > 0.f;

	moveVec2D = {moveVec2D.x * c - moveVec2D.y * s, moveVec2D.x * s + moveVec2D.y * c};
	Vec3 moveVec;

		Vec3 *localPlayerPos = localPlayer->getPos();

		float yaw = localPlayer->getActorRotationComponent()->rot.y;
		Vec2 moveVec2d = {input->forwardMovement, -input->sideMovement};
		bool pressed = moveVec2d.magnitude() > 0.01f;

		if (input->isJumping)
			localPlayer->entityLocation->velocity.y += upanddown;

		if (input->isSneakDown)
			localPlayer->entityLocation->velocity.y -= upanddown;

		if (input->right) {
			yaw += 90.f;

			if (input->forward)
				yaw -= 45.f;
			else if (input->backward)
				yaw += 45.f;
		}

		if (input->left) {
			yaw -= 90.f;

			if (input->forward)
				yaw += 45.f;
			else if (input->backward)
				yaw -= 45.f;
		}

		if (input->backward && !input->left && !input->right)
			yaw += 180.f;

		if (pressed) {
			float calcYaw = (yaw + 90.f) * (PI / 180.f);
			Vec3 moveVec;
			moveVec.x = cos(calcYaw) * speed;
			moveVec.y = localPlayer->entityLocation->velocity.y;
			moveVec.z = sin(calcYaw) * speed;
			localPlayer->lerpMotion(moveVec);

			if (border) {
				if (pressed) {
					Vec3 *pos = Game.getLocalPlayer()->getPos();
					if ((pos->x <= 1094) || (pos->z <= 1094) || (pos->x >= 63) || (pos->z >= 63)) {
						tmp = 1;
					}
					if ((pos->x > 1090) || (pos->z > 1090) || (pos->x <= 60) || (pos->z < 60)) {
						player->velocity.y = -0.02;

						int speedIndexThingyForHive = 73;

						float epicHiveSpeedArrayThingy[31] = {
							0.50

						};
						{
						LocalPlayer *player = Game.getLocalPlayer();
						if (player == nullptr) return;
						Vec3 moveVec;
						Vec2 moveVec2d = {input->forwardMovement, -input->sideMovement};
						// float calcYaw = (PI / 180);

						float c = cos(calcYaw);
						float s = sin(calcYaw);
						moveVec2d = {moveVec2d.x * c - moveVec2d.y * s, moveVec2d.x * s + moveVec2d.y * c};

						if (pressed) {
							speedIndexThingyForHive = 0;
							float currentSpeed = epicHiveSpeedArrayThingy[speedIndexThingyForHive];
							moveVec.x = moveVec2d.x * currentSpeed;
							moveVec.z = moveVec2d.y * currentSpeed;
							if (player->onGround)
								moveVec.y = -0.010f;
							else
								moveVec.y = player->velocity.y;
							player->lerpMotion(moveVec);
							if (speedIndexThingyForHive < 71) speedIndexThingyForHive++;
						}
					}
				}
			}
		}
	}
}

void Fly::onEnable() {
Game.getClientInstance()->minecraft->setTimerSpeed(26.f);
}

void Fly::onDisable() {
	if (Game.getLocalPlayer() != nullptr)
		Game.getLocalPlayer()->aabb.upper.y = Game.getLocalPlayer()->aabb.lower.y + (float)1.8f;
	Game.getClientInstance()->minecraft->setTimerSpeed(20.f);
}

class AirJump : public IModule {
public:
	int hasJumped = 0.0001;
	bool legacyMode = false;

	AirJump() : IModule(0x0, Category::MOVEMENT, "Jump even you're not on the ground") {
		registerBoolSetting("Legacy", &legacyMode, legacyMode);
	};
	~AirJump(){};

	void onTick(GameMode *gm) {
		if (legacyMode) {
			gm->player->onGround = true;
			return;
		}
		GameSettingsInput *input = Game.getClientInstance()->getGameSettingsInput();

		if (input == nullptr)
			return;

		if (GameData::isKeyDown(*input->spaceBarKey) && hasJumped == 0) {
			gm->player->onGround = true;
			hasJumped = 0.0001;
		} else if (!GameData::isKeyDown(*input->spaceBarKey)) {
			hasJumped = 0.0001;
		}
	}

	virtual const char *getModuleName() override {
		return "bypass";
	}
};

class AutoJump : public IModule {
public:
	AutoJump() : IModule(0x0, Category::MOVEMENT, "Automatically jump") {}
	~AutoJump(){};

	// Inherited via IModule
	virtual const char *getModuleName() override { return ("bypass"); }
	virtual void onTick(GameMode *gm) override {
		LocalPlayer *player = Game.getLocalPlayer();

		if (player->onGround) player->jumpFromGround();
	}
};


	
	


