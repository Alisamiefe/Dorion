#include "Killaura3.h"

Killaura3::Killaura3() : IModule(0x0, Category::COMBAT, "Killaura for mobs and kids") {
	mode.addEntry(EnumEntry("Single", 0))
		.addEntry(EnumEntry("Multi", 1));
	registerEnumSetting("Mode", &mode, 0);
	registerBoolSetting("MobAura", &isMobAura, isMobAura);
	registerFloatSetting("Range", &range, range, 2.f, 20.f);
	registerBoolSetting("AutoWeapon", &autoweapon, autoweapon);
}

Killaura3::~Killaura3() {
}

const char* Killaura3::getModuleName() {
	return ("Killaura");
}

static std::vector<Entity*> targetList;
struct CompareTargetEnArray {
	bool operator()(Entity* lhs, Entity* rhs) {
		LocalPlayer* localPlayer = Game.getLocalPlayer();
		return (*lhs->getPos()).dist(localPlayer->getMovementProxy()->getPos()) < (*rhs->getPos()).dist(localPlayer->getMovementProxy()->getPos());
	}
};

void findEntityH(Entity* currentEntity, bool isRegularEntity) {
	static auto killaura3Mod = moduleMgr->getModule<Killaura3>();

	if (currentEntity == nullptr)
		return;

	if (currentEntity == Game.getLocalPlayer())  // Skip Local player
		return;

	if (!Game.getLocalPlayer()->canAttack(currentEntity, false))
		return;

	if (!Game.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (currentEntity->getEntityTypeId() == 66)  // falling block
		return;

	if (currentEntity->getEntityTypeId() == 69)  // XP
		return;

	if (killaura3Mod->isMobAura) {
		if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->isPlayer())
			return;
		if (currentEntity->getAABBShapeComponent()->aabb.width <= 0.01f || currentEntity->getAABBShapeComponent()->aabb.height <= 0.01f)  // Don't hit this pesky antibot on 2b2e.org
			return;
		if (currentEntity->getEntityTypeId() == 64)  // item
			return;
		if (currentEntity->getEntityTypeId() == 80)  // Arrows
			return;
		if (currentEntity->getEntityTypeId() == 51)  // NPC
			return;
	} else {
		if (!Target::isValidTarget(currentEntity))
			return;
	}

	float dist = (*currentEntity->getPos()).dist(*Game.getLocalPlayer()->getPos());

	if (dist < killaura3Mod->range) {
		targetList.push_back(currentEntity);
	}
}

void Killaura3::findWeapon() {
	PlayerInventoryProxy* supplies = Game.getLocalPlayer()->getSupplies();
	Inventory* inv = supplies->inventory;
	float damage = 0;
	int slot = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			float currentDamage = stack->getAttackingDamageWithEnchants();
			if (currentDamage > damage) {
				damage = currentDamage;
				slot = n;
			}
		}
	}
	supplies->selectedHotbarSlot = slot;
}

decltype(GetTickCount64()) startV;
bool CounterV(double a1) {
	if ((GetTickCount64() - startV) >= a1) {
		startV = GetTickCount64();
		return true;
	}
	return false;
}


void Killaura3::onEnable() {
	targetList.clear();
	if (Game.isInGame()) {
		if (Game.getLocalPlayer() == nullptr)
			setEnabled(false);
	}
}
void Killaura3::onDisable() {
	targetList.clear();
}


