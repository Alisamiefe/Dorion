#pragma once

#include "../ModuleManager.h"
#include "Module.h"

class DamageVis : public IModule {
public:
	bool VisTarget = true;
	bool hurttime = false;
	int targethud = 0;
	int counter = 0;
	int range = 40.f;

	float opacity = 1.f;

	DamageVis();
	~DamageVis();

	// Inherited via IModule
	virtual void onTick(GameMode* gm);
	virtual const char* getModuleName() override;
	virtual void onEnable() override;
	virtual void onDisable() override;
	virtual void onLevelRender() override;
};