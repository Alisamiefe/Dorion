﻿#include "Killaura2.h"

Killaura2::Killaura2() : IModule('0x0', Category::CLIENT2, "Killaura by DinoXz 2") {
	registerFloatSetting("range", &range, range, 0.f, 80.f);
	registerIntSetting("hits", &delay, delay, 0, 7);
	registerEnumSetting("Targeting", &targ, 2);
	targ = SettingEnum(this)
			   .addEntry(EnumEntry("Switch", 0))
			   .addEntry(EnumEntry("Multi", 1))
			   .addEntry(EnumEntry("Single", 2));
	this->registerIntSetting("CPS multiplier", &this->mult, this->mult, 1, 100);
	registerEnumSetting("Rotations Menu", &rots, 5);
	rots = SettingEnum(this)
			   .addEntry(EnumEntry("AuraV1", 0))
			   .addEntry(EnumEntry("AuraV2", 1))
			   .addEntry(EnumEntry("AuraV3", 2))
			   .addEntry(EnumEntry("AuraV4", 3))
			   .addEntry(EnumEntry("AuraV5", 4))
			   .addEntry(EnumEntry("None", 5));
	//registerBoolSetting("hurttime", &hurttime, hurttime);
	registerBoolSetting("AutoSword", &autoweapon, autoweapon);
	//registerBoolSetting("NoSwing", &noSwing, noSwing);
	this->registerBoolSetting("Double CPS", &this->cps, this->cps);
	this->registerBoolSetting("Visualise Target", &this->VisTarget, this->VisTarget);
}

Killaura2::~Killaura2() {
}

const char* Killaura2::getModuleName() {
	return ("KillauraV2");
}

static std::vector<Entity*> targetList;

void findEntityhh(Entity* currentEntity, bool isRegularEntity) {
	static auto killaura2Mod = moduleMgr->getModule<Killaura2>();

	if (currentEntity == nullptr)
		return;

	if (currentEntity == Game.getLocalPlayer())  // Skip Local player
		return;

	if (!Game.getLocalPlayer()->canAttack(currentEntity, false))
		return;

	if (!Game.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (killaura2Mod->isMobAura) {
		if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 63)  // this means target every mob a-part from the player!
			return;
		if (currentEntity->getAABBShapeComponent()->aabb.width <= 0.01f || currentEntity->getAABBShapeComponent()->aabb.height <= 0.01f)  // Don't hit this pesky antibot on 2b2e.org
			return;
		if (currentEntity->getEntityTypeId() == 64)  // item
			return;
	} else {
		if (!Target::isValidTarget(currentEntity))
			return;
	}

	float dist = (*currentEntity->getPos()).dist(*Game.getLocalPlayer()->getPos());

	if (dist < killaura2Mod->range) {
		targetList.push_back(currentEntity);
	}
}
void Killaura2::findWeapon() {
	PlayerInventoryProxy* supplies = Game.getLocalPlayer()->getSupplies();
	Inventory* inv = supplies->inventory;
	float damage = 0;
	int slot = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			float currentDamage = stack->getAttackingDamageWithEnchants();
			if (currentDamage > damage) {
				damage = currentDamage;
				slot = n;
			}
		}
	}
	supplies->selectedHotbarSlot = slot;
}

int PlayerCount = 0;

void Killaura2::onTick(GameMode* gm) {
	LocalPlayer* player = Game.getLocalPlayer();
	targetList0 = targetList.empty();

	if (!player->isAlive())
		return;

	targetList.clear();

	Game.forEachEntity(findEntityhh);
	if (autoweapon) findWeapon();

	if (!targetList.empty() && Game.isInGame() && Game.getLocalPlayer() != nullptr) {
		PlayerCount++;

		Odelay++;
		if (PlayerCount >= targetList.size())
			PlayerCount = 0;

		if (Odelay >= delay) {
			for (auto& i : targetList) {
				if (!(i->damageTime > 100 && hurttime)) {
					Game.getGameMode()->attack(i);
					Game.getLocalPlayer()->swing();
					Game.getGameMode()->attack(i);
					Game.getLocalPlayer()->swing();
					Game.getGameMode()->attack(i);
					Game.getLocalPlayer()->swing();
					if (noSwing)
						return;
					targethud++;
				} else {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getGameMode()->attack(i);
						Game.getGameMode()->attack(i);
					
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 1) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						if (noSwing)
							return;
						targethud++;
					} else {
						
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 2) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);

						if (noSwing)
							return;
						targethud++;
					} else {
						
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 3) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);

						if (noSwing)
							return;
						targethud++;
					} else {
						
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 4) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						if (noSwing)
							return;
						targethud++;
					} else {
						
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 5) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						if (noSwing)
							return;
						targethud++;
					} else {
						
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 6) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);

						if (noSwing)
							return;
						targethud++;
					} else {
						targethud = 1;
					}
				}
			}
		}

		if (Odelay >= delay) {
			if (Odelay == 7) {
				for (auto& i : targetList) {
					if (!(i->damageTime > 100 && hurttime)) {
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						Game.getGameMode()->attack(i);
						Game.getLocalPlayer()->swing();
						if (noSwing)
							return;
						targethud++;
					} else {
						targethud = 1;
					}
				}
			}
		}

		if (targetList.empty()) {
			counter = 0;
			PlayerCount = 0;
		}
		if (!targetList.empty() && Game.isInGame() && Game.getLocalPlayer() != nullptr && !noSwing)
			player->swing();
	}
}

void Killaura2::onEnable() {
	if (Game.getLocalPlayer() == nullptr)
		this->setEnabled(false);
}


void Killaura2::onDisable() {
	targetList.clear();
}

float tt = 0;
void Killaura2::onLevelRender() {
	auto player = Game.getLocalPlayer();
	if (player == nullptr) return;

	targetList.clear();

	Game.forEachEntity(findEntityhh);
	if (!targetList.empty() && VisTarget && Game.isInGame()) {
		tt++;
		DrawUtils::setColor(255, 255, 255, 1);

		Vec3 permutations[37];
		for (int i = 0; i < 37; i++) {
			permutations[i] = {sinf((i * 10.f) / (180 / PI)), 0.f, cosf((i * 10.f) / (180 / PI))};
		}

		const float coolAnim = 0.9f + 0.9f * sin((tt / 60) * PI * 2);

		Vec3* start;
		Vec3* end;

		if (!(targetList[0]->damageTime > 1 && hurttime)) {
			start = targetList[0]->getPosOld();
			end = targetList[0]->getPos();
		}

		auto te = DrawUtils::getLerpTime();
		Vec3 pos = start->lerp(end, te);

		auto yPos = pos.y;
		yPos -= 1.40f;
		yPos += coolAnim;

		std::vector<Vec3> posList;
		posList.reserve(40);
		for (auto& perm : permutations) {
			Vec3 curPos(pos.x, yPos, pos.z);
			posList.push_back(curPos.add(perm));
		}

		DrawUtils::drawLinestrip3d(posList);
	}
}

void Killaura2::onPlayerTick(Player* plr) {
	if (plr == nullptr)
		return;
	if (Game.getLocalPlayer() != nullptr && !targetList.empty()) {
		if (targetList[0] == nullptr)
			return;

		if (rots.selected == 0) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getMovementProxy()->setRot(ange);
		}
		if (rots.selected == 1) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorRotationComponent()->rot.x = ange.x;
			plr->getActorRotationComponent()->rot = ange;
			plr->getActorHeadRotationComponent()->rot.y = ange.y;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 2) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorHeadRotationComponent()->rot = ange;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMobBodyRotationComponent()->prevBodyRot = ange.y;
			plr->getMovementProxy()->setRot(ange);
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 3) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(*targetList[0]->getPos());
			// Reduce speed by 25%
			float reducedSpeedX = plr->getSpeed() * 0.75f;
			float reducedSpeedZ = plr->getSpeed() * 0.75f;

			// Set the reduced speed
			plr->setSpeed(reducedSpeedX);
			plr->setSpeed(reducedSpeedZ);
			plr->getActorRotationComponent()->rot = ange;
			plr->getActorHeadRotationComponent()->rot.y = ange.y;
			plr->getActorHeadRotationComponent()->rot.x = ange.x;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMovementProxy()->setActorRotation(ange.x);
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 4) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getPos());
			plr->getActorHeadRotationComponent()->rot = ange;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMobBodyRotationComponent()->prevBodyRot = ange.y;
			plr->getMovementProxy()->setRot(ange);
		}
	}
}
