#include "Arraylist.h"

#include "../../../Utils/ColorUtil.h"
// #include "../../Utils/setColor.h"
#include "../../Utils/ClientColors.h"

Arraylist::Arraylist() : IModule(0, Category::CUSTOM, "Display your enabled modules on the HUD!") {
	// registerFloatSetting("Opacity", &alpha, alpha, 0.f, 1.f);
	registerBoolSetting("Side Bar", &Bar, Bar);
	registerBoolSetting("Under Bar", &Bar2, Bar2);
}

Arraylist::~Arraylist() {
}

const char* Arraylist::getModuleName() {
	return ("Arraylist");
}

struct IModuleContainer {
	std::shared_ptr<IModule> backingModule;
	std::string moduleName;
	bool enabled;
	int keybind;
	float textWidth;
	Vec2* pos;
	bool shouldRender = true;

	IModuleContainer(std::shared_ptr<IModule> mod) {
		static auto arrayMod = moduleMgr->getModule<Arraylist>();
		static auto hudMod = moduleMgr->getModule<HudModule>();
		const char* moduleNameChr = mod->getModuleName();
		enabled = mod->isEnabled();
		keybind = mod->getKeybind();
		backingModule = mod;
		pos = mod->getPos();

		if (keybind == 0x0)
			moduleName = moduleNameChr;
		else {
			char text[50];
			sprintf_s(text, 50, "%s%s", moduleNameChr, hudMod->keybinds ? (" [" + std::string(Utils::getKeybindName(keybind)) + "]").c_str() : "");
			moduleName = text;
		}

		if (!enabled && *pos == Vec2(0.f, 0.f))
			shouldRender = false;
		textWidth = DrawUtils::getTextWidth(&moduleName, hudMod->scale);
	}

	bool operator<(const IModuleContainer& other) const {
		if (textWidth == other.textWidth)
			return moduleName < other.moduleName;
		return textWidth > other.textWidth;
	}
};

void Arraylist::onPostRender(MinecraftUIRenderContext* renderCtx) {
	static auto partner = moduleMgr->getModule<Partner>();
	static auto hudMod = moduleMgr->getModule<HudModule>();

	Vec2 windowSize = Game.getClientInstance()->getGuiData()->windowSize;
	Vec2 windowSizeReal = Game.getClientInstance()->getGuiData()->windowSizeReal;
	Vec2 mousePos = *Game.getClientInstance()->getMousePos();

	// Convert mousePos to visual Pos
	mousePos = mousePos.div(windowSizeReal).mul(windowSize);

	// Mouse click detector
	static bool wasLeftMouseDown = GameData::isLeftClickDown();
	bool leftMouseDown = GameData::isLeftClickDown();
	bool executeClick = leftMouseDown && leftMouseDown != wasLeftMouseDown;
	wasLeftMouseDown = leftMouseDown;

	std::set<IModuleContainer> modContainerList;
	// Fill modContainerList with Modules
	{
		auto lock = moduleMgr->lockModuleList();
		std::vector<std::shared_ptr<IModule>>* moduleList = moduleMgr->getModuleList();
		for (auto it : *moduleList) {
			if (it.get() != hudMod)
				modContainerList.emplace(IModuleContainer(it));
		}
	}

	// Parameters
	float textSize = hudMod->scale;
	float textPadding = 1.0f * textSize;
	float textHeight = 10.0f * textSize;
	float smoothness = 2;
	float yOffset = 0;
	int index = 0;

	for (const auto& container : modContainerList) {
		if (!container.shouldRender)
			continue;

		auto textStr = container.moduleName;
		auto textWidth = container.textWidth;

		static float rcolors[4];          // Rainbow color array RGBA
		static float disabledRcolors[4];  // Rainbow Colors, but for disabled modules
		static float currColor[4];        // ArrayList colors
		static float SurgeColor[4];       // ArrayList colors
		int separation = 50;

		int a = 0;
		int b = 0;
		int c = 0;
		{
			{
				{
					Utils::ApplyRainbow(currColor, 0.00015f), index * (separation * 2);	  // Increase Hue of rainbow color array
					if (rcolors[3] < 1) {
						rcolors[0] = 0.2f;
						rcolors[1] = 0.2f;
						rcolors[2] = 1.f;
						rcolors[3] = 1;
					}
				}
				Utils::ApplyRainbow(currColor, 0.00015f), index * (separation * 2);
				if (currColor[0] += 1.f / a * c, separation * 2) {
					currColor[0] += 1.f / a * c;
				}
			}
		}
		Utils::ColorConvertRGBtoHSV(rcolors[0], rcolors[1], rcolors[2], currColor[0], currColor[1], currColor[2]);
		Utils::ColorConvertHSVtoRGB(currColor[0], currColor[1], currColor[2], currColor[0], currColor[3], currColor[3]);

		auto arrayColor = MC_Color(0, 0, 255);

		auto AqqrrayColor = MC_Color(0, 255, 455);

		auto xOffsetOri = windowSize.x - textWidth - (textPadding * 2);
		auto xOffset = windowSize.x - container.pos->x;

		container.pos->x = lerp(container.enabled ? windowSize.x - xOffsetOri : -1.f, container.pos->x, 0.04);
		if (xOffset >= windowSize.x && !container.enabled) {
			container.pos->x = 0.f;
			container.pos->y = 0.f;
		}

		auto textPos = Vec2(xOffset + textPadding, yOffset + textPadding);
		auto rectPos = Vec4(xOffset - 2, yOffset, windowSize.x, yOffset + textPadding * 2 + textHeight);
		auto sideRect = Vec4(xOffset - 2, yOffset, xOffset - 1, yOffset + textPadding * 2 + textHeight);
		auto FluxRect = Vec4(xOffset - 2, yOffset, xOffset - 1, yOffset + textPadding * 2 + textHeight);

		if (alpha > 0) {
			DrawUtils::fillRectangle(rectPos, MC_Color(0, 0, 0), alpha);
		}
		if (Bar) {
			DrawUtils::fillRectangle(sideRect, currColor, 1.f);
			if (partner->Partnered.selected == 0) {
				DrawUtils::fillRectangle(sideRect, currColor, 1.f);
			} else if (partner->Partnered.selected == 1) {
				DrawUtils::fillRectangle(sideRect, arrayColor, 1.f);
			} else if (partner->Partnered.selected == 2) {
				DrawUtils::fillRectangle(sideRect, MC_Color(5, 255, 205), 1.f);
			}
			if (Bar2) {
				DrawUtils::fillRectangle(Vec4{rectPos.x, rectPos.w, rectPos.z, rectPos.w + 1.f}, currColor, 1.f);
				if (partner->Partnered.selected == 0) {
					DrawUtils::fillRectangle(Vec4{rectPos.x, rectPos.w, rectPos.z, rectPos.w + 1.f}, currColor, 1.f);
				} else if (partner->Partnered.selected == 1) {
					DrawUtils::fillRectangle(Vec4{rectPos.x, rectPos.w, rectPos.z, rectPos.w + 1.f}, arrayColor, 1.f);
				} else if (partner->Partnered.selected == 2) {
					DrawUtils::fillRectangle(Vec4{rectPos.x, rectPos.w, rectPos.z, rectPos.w + 1.f}, MC_Color(5, 255, 205), 1.f);
				}
			}
		}
		if (!GameData::canUseMoveKeys() && rectPos.contains(&mousePos) && clickToggle) {
			auto selectedRect = rectPos;
			selectedRect.x = sideRect.z;
			if (leftMouseDown) {
				DrawUtils::fillRectangle(selectedRect, MC_Color(0.8f, 0.8f, 0.8f), 0.8f);
				if (executeClick)
					container.backingModule->toggle();
			} else {
				DrawUtils::fillRectangle(selectedRect, MC_Color(0.8f, 0.8f, 0.8f, 0.8f), 0.3f);
			}
		}
		DrawUtils::drawText(textPos, &textStr, currColor, textSize);
		if (partner->Partnered.selected == 0) {
			DrawUtils::drawText(textPos, &textStr, currColor, textSize);
		} else if (partner->Partnered.selected == 1) {
			DrawUtils::drawText(textPos, &textStr, arrayColor, textSize);
		} else if (partner->Partnered.selected == 2) {
			DrawUtils::drawText(textPos, &textStr, AqqrrayColor, textSize);
		}
		yOffset += ((10.0f * textSize) + (textPadding * 2)) * ((windowSize.x - xOffset) / (windowSize.x - xOffsetOri));
		++index;
	}
	modContainerList.clear();
}