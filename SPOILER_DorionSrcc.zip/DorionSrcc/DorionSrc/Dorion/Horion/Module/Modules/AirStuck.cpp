#include "AirStuck.h"

AirStuck::AirStuck() : IModule(0, Category::CLIENT, "Become stuck.") {
}

AirStuck::~AirStuck() {
}

const char* AirStuck::getModuleName() {
	return ("AirStuck");
}

void AirStuck::onTick(GameMode* gm) {
	gm->player->entityLocation->velocity = Vec3(0, -5, 0);
}