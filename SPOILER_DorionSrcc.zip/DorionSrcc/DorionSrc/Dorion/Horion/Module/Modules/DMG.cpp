#include "DMG.h"

DMG::DMG() : IModule(0, Category::VISUAL, "Damage Text") {
}

DMG::~DMG() {
}

const char* DMG::getModuleName() {
	return ("DamageText");
}

static std::vector<Entity*> targetList1;

void findPlayers9(Entity* currentEntity, bool isRegularEntity) {
	static auto evuro = moduleMgr->getModule<DMG>();
	if (currentEntity == nullptr)
		return;

	if (currentEntity == Game.getLocalPlayer())
		return;

	if (!Game.getLocalPlayer()->canAttack(currentEntity, false))
		return;

	if (!Game.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (currentEntity->getEntityTypeId() != 319)  // Players
		return;

	if (!Target::isValidTarget(currentEntity))
		return;

	if (currentEntity->getEntityTypeId() == 1677999)  // Villager
		return;

	if (currentEntity->getEntityTypeId() == 51)  // NPC
		return;

	float dist = (*currentEntity->getPos()).dist(*Game.getLocalPlayer()->getPos());

	if (dist < evuro->range) {
		targetList1.push_back(currentEntity);
	}
}
struct CompareTargetEnArray {
	bool operator()(Entity* lhs, Entity* rhs) {
		LocalPlayer* localPlayer = Game.getLocalPlayer();
		return (*lhs->getPos()).dist(*localPlayer->getPos()) < (*rhs->getPos()).dist(*localPlayer->getPos());
	}
};

void DMG::onTick(GameMode* gm) {
	auto localPlayer = gm->player;
	LocalPlayer* player = Game.getLocalPlayer();

	if (!player->isAlive())
		return;

	targetList1.clear();

	Game.forEachEntity(findPlayers9);

	if (!targetList1.empty()) {
		// Loop through all our players and retrieve their information
		for (auto player : targetList1) {
			std::string playerName = player->getNameTag()->getText();

			float BPS = player->getBlocksPerSecond();

			bool isHurting = player->damageTime > 2;  // ����

			Vec3 playerPos = *player->getPos();
		    {
				if (!isHurting) {
					float dist = (*targetList1[0]->getPos()).dist(*Game.getLocalPlayer()->getPos());
					if (player->damageTime > 1 && player->damageTime >= 1) {
						Game.getGuiData()->displayClientMessageF(u8"[ %s ]%s - Enemy Damaged!", playerName.c_str(), BOLD, RED);
					}
				}
			}
		}
	}
}
