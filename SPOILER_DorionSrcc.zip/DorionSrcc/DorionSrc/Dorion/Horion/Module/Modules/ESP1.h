#pragma once

#include "../ModuleManager.h"
#include "Module.h"

class ESP1 : public IModule {
public:
	bool isMobEsp = false;
	bool is2d = false;
	bool iszephyr = false;
	bool betterESP = false;
	bool circle = true;
	bool circle1 = true;
	bool item = false;
	bool isMobAura = false;
	float height = 1.80;
	float width = 0.60;
	float range = 8;

	float opacity = 1.f;

	ESP1();
	~ESP1();

	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onEnable() override;
	virtual void onLevelRender() override;
};