#include "ESP1.h"

#include "../../../Utils/Target.h"

ESP1::ESP1() : IModule('O', Category::VISUAL, "Visualize entitys in combat") {

	// registerBoolSetting("MobESP1", &isMobEsp, isMobEsp);
	//	registerBoolSetting("2d", &is2d, is2d);
	// registerBoolSetting("ItemESP1", &item, item);
	//	registerBoolSetting("Zephyr ESP1", &iszephyr, iszephyr);
	//	registerBoolSetting("Better ESP1", &betterESP, betterESP);
	//registerBoolSetting("V1", &circle, circle);
	//registerBoolSetting("V2", &circle1, circle1);
}

ESP1::~ESP1() {
}

const char* ESP1::getModuleName() {
	return "Visualize";
}

static float rcolors[4];
std::vector<Vec3i> lastPos;
void ESP1::onEnable() {
	lastPos.clear();
}


float r = 0;
void ESP1::onLevelRender() {
	static auto partner = moduleMgr->getModule<Partner>();
	if (circle) {
		DrawUtils::setColor(14, 0, 255, 1);
		if (partner->Partnered.selected == 0) {
			DrawUtils::setColor(14, 0, 255, 1);
		}
		if (partner->Partnered.selected == 1) {
			DrawUtils::setColor(0, 0, 255, 1);
		}
		if (partner->Partnered.selected == 2) {
			DrawUtils::setColor(0, 255, 455, 1);
		}

		Vec3 permutations[36];
		for (int i = 0; i < 36; i++) {
			permutations[i] = {sinf((i * 60.f) / (80 / PI)), 0.f, cosf((i * 60.f) / (80 / PI))};
		}

		const float coolAnim = 0.9f + 0.6f * sin((r / 60) * PI * 0.5);

		Game.forEachEntity([&](Entity* ent, bool valid) {
			static auto noFriendsModule = moduleMgr->getModule<NoFriends>();
			if (!noFriendsModule->isEnabled() && !FriendsManager::findFriend(ent->getNameTag()->getText())) {
				if (ent != Game.getLocalPlayer() && Target::isValidTarget(ent)) {
					Vec3* start = ent->getPosOld();
					Vec3* end = ent->getPos();

					auto te = DrawUtils::getLerpTime();
					Vec3 pos = start->lerp(end, te);

					auto yPos = pos.y;
					yPos -= 1.40f;
					yPos += coolAnim;

					std::vector<Vec3> posList;
					posList.reserve(40);
					for (auto& perm : permutations) {
						Vec3 curPos(pos.x, yPos, pos.z);
						posList.push_back(curPos.add(perm));
					}

					DrawUtils::drawLinestrip3d(posList);
				}
			}
		});
	}

	if (circle1) {
		r++;
		DrawUtils::setColor(14, 0, 255, 1);
		if (partner->Partnered.selected == 0) {
			DrawUtils::setColor(14, 0, 255,1);
		}
		if (partner->Partnered.selected == 1) {
			DrawUtils::setColor(0, 0, 255,1);
		}
		if (partner->Partnered.selected == 2) {
			DrawUtils::setColor(0, 255, 455,1);
		}

		Vec3 permutations[36];
		for (int i = 0; i < 36; i++) {
			permutations[i] = {sinf((i * 9.f) / (120 / PI)), 0.f, cosf((i * 9.f) / (120 / PI))};
		}

		const float coolAnim = 0.9f + 0.6f * sin((r / 60) * PI * 0.5);

		Game.forEachEntity([&](Entity* ent, bool valid) {
			static auto noFriendsModule = moduleMgr->getModule<NoFriends>();
			if (!noFriendsModule->isEnabled() && !FriendsManager::findFriend(ent->getNameTag()->getText())) {
				if (ent != Game.getLocalPlayer() && Target::isValidTarget(ent)) {
					Vec3* start = ent->getPosOld();
					Vec3* end = ent->getPos();

					auto te = DrawUtils::getLerpTime();
					Vec3 pos = start->lerp(end, te);

					auto yPos = pos.y;
					yPos -= 1.40f;
					yPos += coolAnim;

					std::vector<Vec3> posList;
					posList.reserve(40);
					for (auto& perm : permutations) {
						Vec3 curPos(pos.x, yPos, pos.z);
						posList.push_back(curPos.add(perm));
					}

					DrawUtils::drawLinestrip3d(posList);
				}
			}
		});
	}
}