#pragma once

#include "../ModuleManager.h"
#include "Module.h"

class ItemESP : public IModule {
public:
	bool mobs = false;
	bool doRainbow = false;
	bool itemESP = true;
	bool is2d = true;
	ItemESP();
	~ItemESP();

	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onPreRender(MinecraftUIRenderContext* renderCtx) override;
};