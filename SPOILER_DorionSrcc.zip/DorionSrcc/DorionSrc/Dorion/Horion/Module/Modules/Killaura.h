#pragma once

#include "../../../Utils/Target.h"
#include "../ModuleManager.h"
#include "Module.h"

class Killaura : public IModule {
public:
	bool silent = false;
	bool isMobAura = false;
	bool hurttime = false;
	int counter = 0;
	bool VisTarget = false;
	SettingEnum mode{this};
	SettingEnum rots{this};
	int z = 0;
	bool autoweapon = false;
	void findWeapon();
	float range = 8;
	bool isSingle = true;
	bool SexyRots = false;
	bool strafe = false;
	bool noSwing = true;
	int delay = 0;
	int idk = 0;
	int Odelay = 0;
	bool targetListP = false;
	int mult = 1;
	Vec2 joe;
	Killaura();
	~Killaura();

	// Inherited via IModule

	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm);
	virtual void onEnable() override;
	virtual void onDisable() override;
	virtual void onPlayerTick(Player* player) override;
	virtual void onLevelRender() override;
};