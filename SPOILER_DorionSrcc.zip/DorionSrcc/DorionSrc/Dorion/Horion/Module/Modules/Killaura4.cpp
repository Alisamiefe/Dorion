#include "Killaura4.h"

Killaura4::Killaura4() : IModule('P', Category::CLIENT2, "Killaura by Fedeaway , fqlix") {
	this->registerBoolSetting("MultiAura", &this->isMulti, this->isMulti);
	this->registerBoolSetting("MobAura", &this->isMobAura, this->isMobAura);
	this->registerFloatSetting("range", &this->range, this->range, 2.f, 50.f);
	this->registerIntSetting("delay", &this->delay, this->delay, 0, 20);
	this->registerIntSetting("CPS multipler", &this->idk, this->idk, 1, 100);
	registerEnumSetting("Rotations Menu", &rots, 5);
	rots = SettingEnum(this)
			   .addEntry(EnumEntry("AuraV1", 0))
			   .addEntry(EnumEntry("AuraV2", 1))
			   .addEntry(EnumEntry("AuraV3", 2))
			   .addEntry(EnumEntry("AuraV4", 3))
			   .addEntry(EnumEntry("AuraV5", 4))
			   .addEntry(EnumEntry("None", 5));
	this->registerBoolSetting("hurttime", &this->hurttime, this->hurttime);
	this->registerBoolSetting("AutoWeapon", &this->autoweapon, this->autoweapon);
	this->registerBoolSetting("Silent Rotations", &this->silent, this->silent);
	this->registerBoolSetting("Target Strafe", &this->strafe, this->strafe);
	this->registerBoolSetting("Double CPS", &this->cps, this->cps);
	this->registerBoolSetting("Visualise Target", &this->VisTarget, this->VisTarget);
}

Killaura4::~Killaura4() {
}

const char* Killaura4::getModuleName() {
	return ("KillauraV3");
}

static std::vector<Entity*> targetListJ;

void findEntityhhD(Entity* currentEntity, bool isRegularEntity) {
	static auto killaura4Mod = moduleMgr->getModule<Killaura4>();

	if (currentEntity == nullptr)
		return;

	if (currentEntity == Game.getLocalPlayer())  // Skip Local player
		return;

	if (!Game.getLocalPlayer()->canAttack(currentEntity, false))
		return;

	if (!Game.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (killaura4Mod->isMobAura) {
		if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 63)  // this means target every mob a-part from the player!
			return;
		if (currentEntity->getAABBShapeComponent()->aabb.width <= 0.01f || currentEntity->getAABBShapeComponent()->aabb.height <= 0.01f)  // Don't hit this pesky antibot on 2b2e.org
			return;
		if (currentEntity->getEntityTypeId() == 64)  // item
			return;
	} else {
		if (!Target::isValidTarget(currentEntity))
			return;
	}

	float dist = (*currentEntity->getPos()).dist(*Game.getLocalPlayer()->getPos());

	if (dist < killaura4Mod->range) {
		targetListJ.push_back(currentEntity);
	}
}

void Killaura4::findWeapon() {
	PlayerInventoryProxy* supplies = Game.getLocalPlayer()->getSupplies();
	Inventory* inv = supplies->inventory;
	float damage = 0;
	int slot = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			float currentDamage = stack->getAttackingDamageWithEnchants();
			if (currentDamage > damage) {
				damage = currentDamage;
				slot = n;
			}
		}
	}
	supplies->selectedHotbarSlot = slot;
}

void Killaura4::onTick(GameMode* gm) {
	// Loop through all our players and retrieve their information
	targetListJ.clear();

	Game.forEachEntity(findEntityhhD);

	Odelay++;
	if (!targetListJ.empty() && Odelay >= delay) {
		if (autoweapon) findWeapon();

		// if (g_Data.getLocalPlayer()->velocity.squaredxzlen() < 0.01) {
		MovePlayerPacket p(Game.getLocalPlayer(), *Game.getLocalPlayer()->getPos());
		Game.getClientInstance()->loopbackPacketSender->sendToServer(&p);  // make sure to update rotation if player is standing still
		//}

		// Attack all entitys in targetList
		if (isMulti) {
			for (auto& i : targetListJ) {
				if (!(i->damageTime > 1 && hurttime)) {
					Game.getLocalPlayer()->swing();
					Game.getGameMode()->attack(i);
				}
			}
		} else {
			if (!(targetListJ[0]->damageTime > 1 && hurttime)) {
				Game.getLocalPlayer()->swing();
				Game.getGameMode()->attack(targetListJ[0]);
			}
		}

		if (isMulti && cps) {
			for (auto& i : targetListJ) {
				if (!(i->damageTime > 1 && hurttime)) {
					Game.getLocalPlayer()->swing();
					Game.getGameMode()->attack(i);
					Game.getLocalPlayer()->swing();
					Game.getGameMode()->attack(i);
				}
			}
		} else {
			if (!(targetListJ[0]->damageTime > 1 && hurttime && cps)) {
				Game.getLocalPlayer()->swing();
				Game.getGameMode()->attack(targetListJ[0]);
				Game.getLocalPlayer()->swing();
				Game.getGameMode()->attack(targetListJ[0]);
			}
		}
		Odelay = 0;
	}
}

void Killaura4::onEnable() {
	if (Game.getLocalPlayer() == nullptr)
		this->setEnabled(false);
}
void Killaura4::onDisable() {
	targetListJ.clear();
}

void Killaura4::onSendPacket(Packet* packet) {
	if (packet->isInstanceOf<MovePlayerPacket>() && Game.getLocalPlayer() != nullptr && silent) {
		if (!targetListJ.empty()) {
			auto* movePacket = reinterpret_cast<MovePlayerPacket*>(packet);
			Vec2 angle = Game.getLocalPlayer()->getPos()->CalcAngle(*targetListJ[0]->getPos());
			movePacket->pitch = angle.x;
			movePacket->headYaw = angle.y;
			movePacket->yaw = angle.y;
		}
	}
}
void Killaura4::onPlayerTick(Player* plr) {
	if (plr == nullptr)
		return;
	if (Game.getLocalPlayer() != nullptr && !targetListJ.empty()) {
		if (targetListJ[0] == nullptr)
			return;

		if (rots.selected == 0) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetListJ[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getMovementProxy()->setRot(ange);
		}
		if (rots.selected == 1) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetListJ[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorRotationComponent()->rot.x = ange.x;
			plr->getActorRotationComponent()->rot = ange;
			plr->getActorHeadRotationComponent()->rot.y = ange.y;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 2) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetListJ[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorHeadRotationComponent()->rot = ange;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMobBodyRotationComponent()->prevBodyRot = ange.y;
			plr->getMovementProxy()->setRot(ange);
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 3) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(*targetListJ[0]->getPos());
			// Reduce speed by 25%
			float reducedSpeedX = plr->getSpeed() * 0.75f;
			float reducedSpeedZ = plr->getSpeed() * 0.75f;

			// Set the reduced speed
			plr->setSpeed(reducedSpeedX);
			plr->setSpeed(reducedSpeedZ);
			plr->getActorRotationComponent()->rot = ange;
			plr->getActorHeadRotationComponent()->rot.y = ange.y;
			plr->getActorHeadRotationComponent()->rot.x = ange.x;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMovementProxy()->setActorRotation(ange.x);
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 4) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetListJ[0]->getMovementProxy()->getPos());
			plr->getActorHeadRotationComponent()->rot = ange;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMobBodyRotationComponent()->prevBodyRot = ange.y;
			plr->getMovementProxy()->setRot(ange);
		}
	}
}

float T = 0;
void Killaura4::onLevelRender() {
	auto player = Game.getLocalPlayer();
	if (player == nullptr) return;

	targetListJ.clear();

	Game.forEachEntity(findEntityhhD);
	if (!targetListJ.empty() && VisTarget && Game.isInGame()) {
		T++;
		DrawUtils::setColor(255, 255, 255, 1);

		Vec3 permutations[37];
		for (int i = 0; i < 37; i++) {
			permutations[i] = {sinf((i * 10.f) / (180 / PI)), 0.f, cosf((i * 10.f) / (180 / PI))};
		}

		const float coolAnim = 0.9f + 0.9f * sin((T / 60) * PI * 2);

		Vec3* start;
		Vec3* end;

		if (!(targetListJ[0]->damageTime > 1 && hurttime)) {
			start = targetListJ[0]->getPosOld();
			end = targetListJ[0]->getPos();
		}

		auto te = DrawUtils::getLerpTime();
		Vec3 pos = start->lerp(end, te);

		auto yPos = pos.y;
		yPos -= 1.40f;
		yPos += coolAnim;

		std::vector<Vec3> posList;
		posList.reserve(40);
		for (auto& perm : permutations) {
			Vec3 curPos(pos.x, yPos, pos.z);
			posList.push_back(curPos.add(perm));
		}

		DrawUtils::drawLinestrip3d(posList);
	}
}