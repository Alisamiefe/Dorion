#include "ItemESP.h"

#include "../../../Utils/Target.h"

ItemESP::ItemESP() : IModule(0x0, Category::VISUAL, "Makes it easier to find entities around you") {
	// this->registerBoolSetting("ESP", &this->doRainbow, this->doRainbow);
	// registerBoolSetting("Mob", &mobs, mobs);
	// this->registerBoolSetting("ItemEsp", &this->itemESP, this->itemESP);
	// this->registerBoolSetting("2d", &this->is2d, this->is2d);
}

ItemESP::~ItemESP() {
}

static float rcolors[4];

const char* ItemESP::getModuleName() {
	return "ItemESP";
}
void drawItemESP(Entity* ent) {
	float width = 1.8f;
	float height = 0.6f;
	float yOffset = 0.5f;

	auto player = Game.getLocalPlayer();
	if (player == nullptr) return;

	float distance = (*player->getPos()).dist(*ent->getPos());

	float scaleFactor = 0.02f;

	float espSize = 0.6f;

	float r = 0.9f;
	float g = 0.2f;
	float b = 0.2f;
	float alpha = 1.0f;

	DrawUtils::setColor(r, g, b, alpha);
	DrawUtils::drawEntityBox(ent, espSize);
}

void doRenderStuff2(Entity* ent, bool isRegularEntitie) {
	static auto esp1 = moduleMgr->getModule<ItemESP>();

	auto player = Game.getLocalPlayer();
	if (ent->timeSinceDeath > 0)
		return;

	else if (esp1->mobs) {
		if (ent->getNameTag()->getTextLength() <= 1 && ent->getEntityTypeId() == 63)
			return;

		if (ent->isInvisible())
			return;

		if (!Game.getLocalPlayer()->canAttack(ent, false))
			return;
		DrawUtils::setColor(rcolors[0], rcolors[1], rcolors[2], (float)fmax(0.1f, (float)fmin(1.f, 15 / (ent->damageTime + 1))));
		MC_Color(180, 60, 255);
	} else if (esp1->itemESP) {
		if (ent->getEntityTypeId() == 64) {
			DrawUtils::setColor(rcolors[0], rcolors[1], rcolors[2], 1.f), (float)fmax(0.1f, (float)fmin(1.f, 15 / (ent->damageTime + 1)));
		} else {
			return;
		}
	} else
		return;
	{
		DrawUtils::drawEntityBox(ent, (float)fmax(0.2f, 1 / (float)fmax(1, (*player->getPos()).dist(*ent->getPos()))));
	}
}

void ItemESP::onPreRender(MinecraftUIRenderContext* renderCtx) {
	LocalPlayer* localPlayer = Game.getLocalPlayer();

	if (localPlayer != nullptr && GameData::canUseMoveKeys()) {
		// Rainbow colors
		{
			if (rcolors[3] < 1) {
				rcolors[0] = 0.2f;
				rcolors[1] = 0.2f;
				rcolors[2] = 1.f;
				rcolors[3] = 1;
			}

			Utils::ApplyRainbow(rcolors, 0.0015f);
		}

		Game.forEachEntity(doRenderStuff2);
	}
}