#include "DamageVis.h"

DamageVis::DamageVis() : IModule('O', Category::VISUAL, "Visualize the hits") {
}

const char* DamageVis::getModuleName() {
	return "DamageVis";
}
DamageVis::~DamageVis() {
}
static std::vector<Entity*> targetList4;

void findPlayers22(Entity* currentEntity, bool isRegularEntity) {
	if (currentEntity == nullptr)
		return;
	if (currentEntity == Game.getLocalPlayer())
		return;

	if (!Game.getLocalPlayer()->canAttack(currentEntity, false)) return;
	if (!Game.getLocalPlayer()->isAlive()) return;
	if (!currentEntity->isAlive()) return;
	if (currentEntity->getEntityTypeId() != 319) return;  // Players
	if (!Target::isValidTarget(currentEntity)) return;
	if (currentEntity->getEntityTypeId() == 1677999) return;  // Villager
	if (currentEntity->getEntityTypeId() == 51) return;       // NPC

	float dist = (*currentEntity->getPos()).dist(*Game.getLocalPlayer()->getPos());

	if (dist < 50) {
		targetList4.push_back(currentEntity);
	}
}

void DamageVis::onTick(GameMode* gm) {
	// Loop through all our players and retrieve their information
	targetList4.clear();

	Game.forEachEntity(findPlayers22);

	for (auto& i : targetList4) {
		if (!(i->damageTime > 1 && hurttime)) {
			targethud++;
		} else
			targethud = 0;
	}
};

float g = 0;

void DamageVis::onLevelRender() {
	auto player = Game.getLocalPlayer();
	if (player == nullptr) return;
	targetList4.empty();
	targetList4.clear();

	Game.forEachEntity(findPlayers22);
	if (!targetList4.empty() && VisTarget && Game.isInGame()) {
		if (targetList4[0]->damageTime > 1) {
			g++;
			DrawUtils::setColor(255.f, 0.f, 0.f, 255.f);

		    Vec3 permutations[36];
			for (int i = 0; i < 36; i++) {
				permutations[i] = {sinf((i * 60.f) / (80 / PI)), 0.f, cosf((i * 60.f) / (80 / PI))};
			}

			const float coolAnim = 0.7f + 0.2f * sin((g / 60) * PI * 4);

			Vec3* start;
			Vec3* end;

			start = targetList4[0]->getPosOld();
			end = targetList4[0]->getPos();

			auto te = DrawUtils::getLerpTime();
			Vec3 pos = start->lerp(end, te);

			auto yPos = pos.y;
			yPos -= 1.50f;
			yPos += coolAnim;

			std::vector<Vec3> posList;
			posList.reserve(50);
			for (auto& perm : permutations) {
				Vec3 curPos(pos.x, yPos, pos.z);
				posList.push_back(curPos.add(perm));
			}

			DrawUtils::drawLinestrip3d(posList);
		}
	}
}

void DamageVis::onEnable() {
}

void DamageVis::onDisable() {
	targetList4.clear();
}