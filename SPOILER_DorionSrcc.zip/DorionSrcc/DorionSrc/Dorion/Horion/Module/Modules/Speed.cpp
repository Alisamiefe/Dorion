#include "Speed.h"

Speed::Speed() : IModule(VK_NUMPAD2, Category::VISUAL, "Zoom up!") {
	registerFloatSetting("Zoom", &speed, 1, 0.10f, 0.12f);
}

Speed::~Speed() {}

const char* Speed::getModuleName() {
	return "Zoom";
}

void Speed::onTick(GameMode* gm) {
	if (auto localPlayer = Game.getLocalPlayer(); localPlayer != nullptr) {
		if (auto speedAdr = reinterpret_cast<float*>(localPlayer->getSpeed() + 0x84); speedAdr != nullptr) {
			*speedAdr = speed;
		}
	}
}

void Speed::onEnable() {
	if (auto localPlayer = Game.getLocalPlayer(); localPlayer != nullptr) {
		origSpeed = *reinterpret_cast<float*>(localPlayer->getSpeed() + 0x84);
	} else {
		setEnabled(false);
	}
}

void Speed::onDisable() {
	if (auto localPlayer = Game.getLocalPlayer(); localPlayer != nullptr) {
		if (auto speedAdr = reinterpret_cast<float*>(localPlayer->getSpeed() + 0x84); speedAdr != nullptr) {
			*speedAdr = origSpeed;
		}
	}
}