#pragma once

#include "Module.h"

class Criticals : public IModule {
public:
	bool test = false;
	float glideMod = -0.001f;
	float glideModEffective = 8.f;
	Criticals();
	~Criticals();

	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm) override;
};
