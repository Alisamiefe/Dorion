﻿#include "Killaura.h"

Killaura::Killaura() : IModule('P', Category::CLIENT2, "Killaura by DinoXz") {
	mode = (*new SettingEnum(this))
			   .addEntry(EnumEntry("Single", 0))
			   .addEntry(EnumEntry("Multi", 1))
			   .addEntry(EnumEntry("Switch", 2));
	registerEnumSetting("Targets mode", &mode, 0);
	this->registerIntSetting("Delay", &this->delay, this->delay, 0, 10);
	this->registerFloatSetting("range", &this->range, this->range, 0.f, 200.f);
	//this->registerIntSetting("CPS multipler", &this->mult, this->mult, 1, 3);  // lol
	this->registerIntSetting("CPS multipler", &this->idk, this->idk, 1, 100);  // lol
	registerEnumSetting("Rotations Menu", &rots, 5);
	rots = SettingEnum(this)
			   .addEntry(EnumEntry("AuraV1", 0))
			   .addEntry(EnumEntry("AuraV2", 1))
			   .addEntry(EnumEntry("AuraV3", 2))
			   .addEntry(EnumEntry("AuraV4", 3))
			   .addEntry(EnumEntry("AuraV5", 4))
			   .addEntry(EnumEntry("None", 5));
	this->registerBoolSetting("AutoSword", &this->autoweapon, this->autoweapon);
	this->registerBoolSetting("ReducerSpam", &this->noSwing, this->noSwing);
	this->registerBoolSetting("strafe", &this->strafe, this->strafe);
	this->registerBoolSetting("Visualise Target", &this->VisTarget, this->VisTarget);
}

Killaura::~Killaura() {
}

const char* Killaura::getModuleName() {
	return ("KillauraV1");
}

static std::vector<Entity*> targetList;

void findEntityhH(Entity* currentEntity, bool isRegularEntity) {
	static auto killauraMod = moduleMgr->getModule<Killaura>();

	if (currentEntity == nullptr)
		return;

	if (currentEntity == Game.getLocalPlayer())  // Skip Local player
		return;

	if (!Game.getLocalPlayer()->canAttack(currentEntity, false))
		return;

	if (!Game.getLocalPlayer()->isAlive())
		return;

	if (!currentEntity->isAlive())
		return;

	if (killauraMod->isMobAura) {
		if (currentEntity->getNameTag()->getTextLength() <= 1 && currentEntity->getEntityTypeId() == 63)  // this means target every mob a-part from the player!
			return;
		if (currentEntity->getAABBShapeComponent()->aabb.width <= 0.01f || currentEntity->getAABBShapeComponent()->aabb.height <= 0.01f)  // Don't hit this pesky antibot on 2b2e.org
			return;
		if (currentEntity->getEntityTypeId() == 64)  // item
			return;
	} else {
		if (!Target::isValidTarget(currentEntity))
			return;
	}

	float dist = (*currentEntity->getPos()).dist(*Game.getLocalPlayer()->getPos());

	if (dist < killauraMod->range) {
		targetList.push_back(currentEntity);
	}
}

void Killaura::findWeapon() {
	PlayerInventoryProxy* supplies = Game.getLocalPlayer()->getSupplies();
	Inventory* inv = supplies->inventory;
	float damage = 0;
	int slot = supplies->selectedHotbarSlot;
	for (int n = 0; n < 9; n++) {
		ItemStack* stack = inv->getItemStack(n);
		if (stack->item != nullptr) {
			float currentDamage = stack->getAttackingDamageWithEnchants();
			if (currentDamage > damage) {
				damage = currentDamage;
				slot = n;
			}
		}
	}
	supplies->selectedHotbarSlot = slot;
}

void Killaura::onTick(GameMode* gm) {
	// Loop through all our players and retrieve their information
	LocalPlayer* player = Game.getLocalPlayer();
	targetListP = targetList.empty();

	if (!player->isAlive())
		return;

	targetList.clear();

	Game.forEachEntity(findEntityhH);
	if (autoweapon) findWeapon();

	Odelay++;
	if (!targetList.empty() && Odelay >= delay) {
		if (z >= targetList.size())
			z = 0;

		Odelay++;
		for (int i = 0; i < mult; i++) {
			switch (mode.selected) {
			case 0:
				for (auto& i : targetList) {
					if (!(targetList[z]->damageTime > 1 && hurttime)) {
						player->swing();
						Game.getGameMode()->attack(targetList[z]);
					}
				}
				break;
			case 1:
				for (auto& i : targetList) {
					if (!(targetList[z]->damageTime > 1 && hurttime)) {
						player->swing();
						Game.getGameMode()->attack(i);
					}
				}
				break;
			case 2:
				for (auto& i : targetList) {
					if (!(targetList[z]->damageTime > 1 && hurttime)) {
						player->swing();
						Game.getGameMode()->attack(targetList[z]);
						Game.getGameMode()->attack(targetList[z]);
					}
				}
			}
			Odelay = 0;
		}
		++z;
	}

	if (!targetList.empty()) {
		for (auto& i : targetList) {
			float dist = (*targetList[0]->getPos()).dist(*Game.getLocalPlayer()->getPos());
			for (auto& i : targetList) {
				if (mode.selected == 0 && strafe && dist < range) {
					Vec2 joe = Game.getLocalPlayer()->getPos()->CalcAngle(*i->getPos()).normAngles();
					// gm->player->setRot(joe);
					gm->player->getActorRotationComponent()->rot.y;
					gm->player->getActorHeadRotationComponent()->rot.x;
					gm->player->getActorHeadRotationComponent()->rot.y;
					gm->player->getMovementProxy()->setYHeadRot(joe.y -2.f);
				}
			}
		}
	}
}

void Killaura::onEnable() {
	if (Game.getLocalPlayer() == nullptr)
		this->setEnabled(false);
}

void Killaura::onPlayerTick(Player* plr) {
	if (plr == nullptr)
		return;
	if (Game.getLocalPlayer() != nullptr && !targetList.empty()) {
		if (targetList[0] == nullptr)
			return;

		if (rots.selected == 0) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorRotationComponent()->rot = ange;
		}
		if (rots.selected == 1) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorRotationComponent()->rot.x = ange.x;
			plr->getActorRotationComponent()->rot = ange;
			plr->getActorHeadRotationComponent()->rot.y = ange.y;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 2) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getAttachPos(ActorLocation::Eyes, 1.f));
			plr->getActorHeadRotationComponent()->rot = ange;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMobBodyRotationComponent()->prevBodyRot = ange.y;
			plr->getMovementProxy()->setRot(ange);
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 3) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(*targetList[0]->getPos());
			// Reduce speed by 25%
			float reducedSpeedX = plr->getSpeed() * 0.75f;
			float reducedSpeedZ = plr->getSpeed() * 0.75f;

			// Set the reduced speed
			plr->setSpeed(reducedSpeedX);
			plr->setSpeed(reducedSpeedZ);
			plr->getActorRotationComponent()->rot = ange;
			plr->getActorHeadRotationComponent()->rot.y = ange.y;
			plr->getActorHeadRotationComponent()->rot.x = ange.x;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMovementProxy()->setActorRotation(ange.x);
			plr->getMovementProxy()->setYHeadRot(ange.y);
		}
		if (rots.selected == 4) {
			Vec2 ange = Game.getLocalPlayer()->getPos()->CalcAngle(targetList[0]->getMovementProxy()->getPos());
			plr->getActorHeadRotationComponent()->rot = ange;
			plr->getMobBodyRotationComponent()->bodyRot = ange.y;
			plr->getMobBodyRotationComponent()->prevBodyRot = ange.y;
			plr->getMovementProxy()->setRot(ange);
		}
	}
}

void Killaura::onDisable() {
	targetList.clear();
}

float t = 0;
void Killaura::onLevelRender() {
	auto player = Game.getLocalPlayer();
	if (player == nullptr) return;

	targetList.clear();

	Game.forEachEntity(findEntityhH);
	if (!targetList.empty() && VisTarget && Game.isInGame()) {
		t++;
		DrawUtils::setColor(255, 255, 255, 1);

			Vec3 permutations[36];
		for (int i = 0; i < 36; i++) {
		permutations[i] = {sinf((i * 10.f) / (180 / PI)), 0.f, cosf((i * 10.f) / (180 / PI))};
		}

		const float coolAnim = 0.9f + 0.6f * sin((t / 60) * PI * 0.5);

		Vec3* start;
		Vec3* end;

		if (!(targetList[0]->damageTime > 1 && hurttime)) {
		start = targetList[0]->getPosOld();
		end = targetList[0]->getPos();
		}

		auto te = DrawUtils::getLerpTime();
		Vec3 pos = start->lerp(end, te);

		auto yPos = pos.y;
		yPos -= 1.40f;
		yPos += coolAnim;

		std::vector<Vec3> posList;
		posList.reserve(40);
		for (auto& perm : permutations) {
		Vec3 curPos(pos.x, yPos, pos.z);
		posList.push_back(curPos.add(perm));
		}

		DrawUtils::drawLinestrip3d(posList);
	}
}

