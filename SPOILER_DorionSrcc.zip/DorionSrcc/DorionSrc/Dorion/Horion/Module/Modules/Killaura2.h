#pragma once

#include "../../../Utils/Target.h"
#include "../ModuleManager.h"
#include "Module.h"

class Killaura2 : public IModule {
public:
	SettingEnum rots;
	SettingEnum targ;
	bool VisTarget = false;
	bool info = true;
	int delay = 0;
	int Odelay = 0;
	bool autoweapon = false;
	void findWeapon();
	int counter = 0;
	int targethud = 0;
	bool noSwing = true;
	bool isMobAura = false;
	bool cps = true;
	bool hurttime = false;
	bool attackSpeedMultiplier = true;
	float range = 15;
	bool targetListA = false;
	int mult = 15;
	bool targetList0 = false;
	Vec2 joe;
	Killaura2();
	~Killaura2();

	// Inherited via IModule

	virtual const char* getModuleName() override;
	virtual void onTick(GameMode* gm);
	virtual void onEnable() override;
	virtual void onDisable() override;
	virtual void onLevelRender() override;
	virtual void onPlayerTick(Player* player) override;
};